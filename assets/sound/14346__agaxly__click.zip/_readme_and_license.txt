Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Agaxly ( https://freesound.org/people/Agaxly/ )

You can find this pack online at: https://freesound.org/people/Agaxly/packs/14346/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 217482__agaxly__turn-on-desktop-lamp-repeatedly.wav
    * url: https://freesound.org/s/217482/
    * license: Creative Commons 0
  * 213004__agaxly__turning-desk-lamp-off.wav
    * url: https://freesound.org/s/213004/
    * license: Creative Commons 0


